# Registry - Diagnostics


## Location Data


## Connection Logs


## Error Logs


### Handling LogEntry data

`wiotp.sdk.api.registry.devices.LogEntry` provides two properties:

- `message` The message content for the log entry
- `timestamp` The time the log was created (`datetime.datetime`)


## Error Codes
